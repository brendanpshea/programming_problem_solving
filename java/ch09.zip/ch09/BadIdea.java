public class BadIdea{
    public static void main(String[] args){
      SuperPet garfield = new SuperPet("Garfield", "Eats Lasagna");
  
      System.out.println(garfield.getName());
    }
  
  }