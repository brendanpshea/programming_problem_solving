package ch09;

public class PetFoodTest {
    public static void main(String[] args) {
        PetFood food = new PetFood("HappyPet", "Dry", 15.5);
        System.out.println(food);
    }
}