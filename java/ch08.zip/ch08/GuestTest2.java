public class GuestTest2 {
    public static void main(String[] args) {
        // TODO: Create three objects representing GuestTest

        // TODO: Show how to use at least one getter method

        // TODO: Show how to use at least one setter method

        // TODO: Display guest info
    }
}