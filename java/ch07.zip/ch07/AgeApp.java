package ch07;
import java.util.Scanner;

public class AgeApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please enter your age: ");
        int age = scanner.nextInt();
        System.out.println("You are " + age + " years old.");
    }
}