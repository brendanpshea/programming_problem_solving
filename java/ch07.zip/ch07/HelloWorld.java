package ch07;
// The package declaration must be the first statement in the file.
// It must match the directory structure where the file is located.

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}